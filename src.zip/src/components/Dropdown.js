import React from 'react'

function Dropdown() {
  return (
<div class="dropdown">
    <button  class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select an option
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
    <li><a href="#">Location</a></li>
      <li class="divider"></li>
    <li><a href="#">Event</a></li>
    </ul>
 </div>
   )
}

export default Dropdown