import React, { Component } from 'react';
import './BarChart'
import BarChart from './BarChart';
class  Dropdown extends Component {
    constructor(props){
      super(props);
     
    }
   
    
  render(){
      return(
<div class="dropdown ">
    <select onClick={this.divstatus} class="btn btn-primary dropdown-toggle"  data-toggle="dropdown">Select an option
    <span class="caret"></span>
    <option value="show">Show</option>
    <option value="hide">hide</option>
    </select>

 </div>
 
   )
}
}

export default Dropdown