import React from 'react'

function Header() {
  return (
    <div>
      
      <div className="App-header"> 
      <h1 className="logo">Audit Logs</h1>
      <a className="export" href="./sample.html" className="export" download class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-export">Export</span> 
      </a>
       </div>
      
    </div>

  )
}

export default Header 