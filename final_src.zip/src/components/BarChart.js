import React from 'react'
import {Bar} from 'react-chartjs-2'

function BarChart() {
    const data = {
        labels:['Mysore','Bangalore','Mumbai'],
        datasets: [
           /* {
                label:'sales for 2020(m)',
                data:[3,2,3,4],
                borderColor:  [
                    'rgba(255,206,86,0.2)',
                    'rgba(255,206,86,0.2)',
                    'rgba(255,206,86,0.2)',
                    'rgba(255,206,86,0.2)',
                    'rgba(255,206,86,0.2)'],
                backgroundColor: [
                'rgba(255,206,86,0.2)',
                'rgba(255,206,86,0.2)',
                'rgba(255,206,86,0.2)',
                'rgba(255,206,86,0.2)',
                'rgba(255,206,86,0.2)']
               
            },*/
            {
                label:'Number of logins',
                data:[1,4,3,7],
                borderColor: [
                'rgba(54,162,235,0.2)',
                'rgba(54,162,235,0.2)',
                'rgba(54,162,235,0.2)',
                'rgba(54,162,235,0.2)',
                'rgba(54,162,235,0.2)'],
                backgroundColor: [
                    'rgba(54,162,235,0.2)',
                    'rgba(54,162,235,0.2)',
                    'rgba(54,162,235,0.2)',
                    'rgba(54,162,235,0.2)',
                    'rgba(54,162,235,0.2)']
                
                
            }
        ]
    }
   const options = {
       title:{
           display: true,
           text:'Bar chart'
       },
       scales: {
           yAxes: [
               {
                   ticks: {
                       min:0,
                       max: 6,
                       stepSize:1
                   }
               }
           ]

       }
   }
    return(
        <Bar data={data} options = {options} />
    )
}
export default BarChart