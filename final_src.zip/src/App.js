import { render } from '@testing-library/react';
import './App.css';
import ReactDOM from "react-dom"
import React, { Component } from 'react';
import '../src/components/BarChart'
import './components/Header'
import './components/Dropdown'
import DateRangePicker from 'react-bootstrap-daterangepicker';
import 'bootstrap-daterangepicker/daterangepicker.css';
import BarChart from './components/BarChart';
import Header from './components/Header';
import PieChart from './components/PieChart';
import  { CreationTable } from './components/CreationTable';
import Dropdown from './components/Dropdown';



class  App extends Component {
  constructor(props){
    super(props);
    this.state={
      show:true
    };
  }

operation(){
  this.setState(
    {
      show:!this.state.show
    }
  )
}

  
render(){
  return (
    <div style={{backgroundColor: "lightblue"}} className="App">
  
 <div className='div1'><Header /></div> 
 
  <div className='div2'>
<button class="btn btn-primary dropdown-toggle" onClick={()=>this.operation()}>Click me</button>
    <div className="date">
    <DateRangePicker
        initialSettings={{ startDate: '1/1/2014', endDate: '3/1/2020' }}
      >
      <button class="btn btn-primary dropdown-toggle">Click here to select Date Range!</button>
    </DateRangePicker>
    </div> 
  </div>

{
  this.state.show?

 <div className='div3'>
      <div className="chart">
        <BarChart />
      </div>


      <div className='piechart'>
      <PieChart/>
      </div>
      
</div>
:null
}

<div className='div4'>
      <div className='table'>
      <CreationTable/>
      </div>
</div> 
 </div>


  );
}
}
export default App;

